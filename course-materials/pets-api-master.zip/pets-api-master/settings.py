SECRET_KEY = 'you-will-never-guess'
DEBUG = True
MONGODB_HOST = 'mongodb' # use 'mongodb' if using Docker
MONGODB_DB = 'pets-api'
